package com.research.mano;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManoApplicationTests {

	@Test
	void contextLoads() {
	}

}
