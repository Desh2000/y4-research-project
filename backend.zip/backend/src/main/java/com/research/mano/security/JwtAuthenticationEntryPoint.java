package com.research.mano.security;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * JWT Authentication Entry Point
 * Handles unauthorized access attempts
 * Returns 401 Unauthorized for invalid or missing JWT tokens
 */
@Component
public class JwtAuthenticationEntryPoint implements AuthenticationEntryPoint {

    @Override
    public void commence(HttpServletRequest request,
                         HttpServletResponse response,
                         AuthenticationException authException) throws IOException, ServletException {

        response.setContentType("application/json");
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

        String errorMessage = "{\n" +
                "  \"error\": \"Unauthorized\",\n" +
                "  \"message\": \"Full authentication is required to access this resource\",\n" +
                "  \"status\": 401,\n" +
                "  \"timestamp\": \"" + java.time.Instant.now() + "\",\n" +
                "  \"path\": \"" + request.getRequestURI() + "\"\n" +
                "}";

        response.getWriter().write(errorMessage);
    }
}
