package com.research.mano.config;

public class WebConfig {
}
